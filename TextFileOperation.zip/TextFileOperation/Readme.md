The project takes text file as Input. 
ProcessInputText.java is for Processing the input text file and storing into Map(linenumber, textoftheline)
Declare all the constant into TextConfiguration.java class
Counting char like(.,! |) as character.


*************************************************************************** 

Test Input

Reading  the is a way of getting information from something that is , written.
Reading involves recognising the symbols that make up a language. 
Reading and hearing are the two most common ways to get , information. 
Information gained from reading can include entertainment, especially when reading fiction or humor.

Pattern string is "reading"

Test Output

Number of Characters: 266
Number of Words 50
Number of Sentences 4
Line Number of Given Patterns: 1,2,3

***************************************************************************
Test Input for Task A

Reading  the is a way of getting information from something that is , written.
Reading involves recognising the symbols that make up a language. 
Reading and hearing are the two most common ways to get , information. 
Information gained from reading can include entertainment, especially when reading fiction or humor.

Test Output


***************************************************************************
Number of Characters: 266
Number of Words 50
Number of Sentences 4

Test Input for Task B
Test Input

Reading  the is a way of getting information from something that is , written.
Reading involves recognising the symbols that make up a language. 
Reading and hearing are the two most common ways to get , information. 
Information gained from reading can include entertainment, especially when reading fiction or humor.

Pattern string is "reading"

Test Output

Line Number of Given Patterns: 1,2,3