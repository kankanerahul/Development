package com.xyz.textOperation;

public class TextConfiguration {
	public static final String TEXT_INPUT_FILE = "TextInput.txt";
	public static final String DELIMITERS = "?!.";
}
