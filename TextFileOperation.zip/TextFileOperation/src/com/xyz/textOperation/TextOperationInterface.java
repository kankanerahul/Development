package com.xyz.textOperation;

import java.util.List;

public interface TextOperationInterface {
	
	public int calculateChar();
	
	public int calculateWords();

	public int calculateSentence();
	
	public List<Integer> matchPattern( String pattern);
	

}
