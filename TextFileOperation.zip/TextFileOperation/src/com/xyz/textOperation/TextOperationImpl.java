package com.xyz.textOperation;

import java.util.List;
import java.util.Map;

import java.util.ArrayList;

public class TextOperationImpl implements TextOperationInterface {
	private Map<Integer, String> inputMap = null;

	public TextOperationImpl(Map<Integer, String> inputMap) {
		this.inputMap = inputMap;
	}

	//Returns number of characters in Input File
	@Override
	public int calculateChar() {

		int countChar = 0;
		if (inputMap.size() == 0)
			return 0;

		for (Map.Entry<Integer, String> entry : inputMap.entrySet()) {
			String strLine = entry.getValue();
			for (int i = 0; i < strLine.length(); i++) {
				char ch = strLine.charAt(i);
				if (ch != ' ')
					countChar++;
			}
		}

		return countChar;

	}

	//Returns number of words in Input File
	@Override
	public int calculateWords() {

	
		int countWords = 0;

		if (inputMap.size() == 0)
			return 0;

		for (Map.Entry<Integer, String> entry : inputMap.entrySet()) {
			String strLine = entry.getValue();
			char ch[] = new char[strLine.length()];

			for (int i = 0; i < strLine.length(); i++) {
				ch[i] = strLine.charAt(i);
				if (((i > 0) && (ch[i] != ' ') && (ch[i - 1] == ' ')) || ((ch[0] != ' ') && (i == 0)))
					countWords++;
			}
		}

		return countWords;
	}

	//Returns number of sentences in Input File
	@Override
	public int calculateSentence() {

		int countSentence = 0;

		if (inputMap.size() == 0)
			return 0;

		for (Map.Entry<Integer, String> entry : inputMap.entrySet()) {
			String strLine = entry.getValue();
			for (int i = 0; i < strLine.length(); i++) {
				if (TextConfiguration.DELIMITERS.indexOf(strLine.charAt(i)) != -1) {
					countSentence++;
				}
			}
		}

		return countSentence;
	}

	//List returning line numbers matching a given pattern in Input File
	@Override
	public List<Integer> matchPattern(String pattern) {

		List<Integer> matchPatternList = new ArrayList<Integer>();

		String newPattern = pattern.toLowerCase();

		if (inputMap.size() == 0)
			return matchPatternList;

		for (Map.Entry<Integer, String> entry : inputMap.entrySet()) {
			String strLine = entry.getValue();
			String newStrLine = strLine.toLowerCase();

			if (newStrLine.contains(newPattern)) {
				matchPatternList.add(entry.getKey());
			}
		}

		return matchPatternList;

	}

}
