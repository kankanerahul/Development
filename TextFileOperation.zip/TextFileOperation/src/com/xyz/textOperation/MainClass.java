package com.xyz.textOperation;

import java.util.List;
import java.util.Map;

public class MainClass {

	public static void main(String[] args) {

		ProcessInputText pInputText = new ProcessInputText();
		pInputText.processTextInput(TextConfiguration.TEXT_INPUT_FILE);
		Map<Integer, String> inputMap = pInputText.getInputTextMap();

		TextOperationImpl textOp = new TextOperationImpl(inputMap);
		System.out.println("Output for Task A ");
		
		//Number of characters in Input File
		int charCount = textOp.calculateChar();
		System.out.println("Number of Characters: " + charCount);

		//Number of words in Input File
		int calculateWords = textOp.calculateWords();
		System.out.println("Number of Words " + calculateWords);

		//Number of sentences in Input File
		int calculateSentence = textOp.calculateSentence();
		System.out.println("Number of Sentences " + calculateSentence);

		//List returning line numbers matching a given pattern in Input File
		String pattern = "reading";
		List<Integer> list = textOp.matchPattern(pattern);
		System.out.println("************************************");
		
		System.out.println("Output for Task B Pattern Matching");
		
		System.out.print("Line Number of Given Patterns: " );
		for (int i = 0; i < list.size()-1; i++) {
			System.out.print(list.get(i)+",");
		}
		System.out.print(list.get(list.size()-1));
		
		
	}

}
