package com.xyz.textOperation;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class ProcessInputText {
	private Map<Integer, String> inputTextMap = null;

	public Map<Integer, String> getInputTextMap() {
		return inputTextMap;
	}

	public void setInputTextMap(Map<Integer, String> inputTextMap) {
		this.inputTextMap = inputTextMap;
	}

	
	//process the input text file
	public void processTextInput(String fileName) {
		FileInputStream fstream = null;
		int id = 0;
		Map<Integer, String> inputMap = new HashMap<Integer, String>();
		try {
			fstream = new FileInputStream(fileName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		String strLine;
		try {
			while ((strLine = br.readLine()) != null) {
				id = id + 1;
				if (strLine.isEmpty())
					continue;

				inputMap.put(id, strLine);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		setInputTextMap(inputMap);
	}

}
